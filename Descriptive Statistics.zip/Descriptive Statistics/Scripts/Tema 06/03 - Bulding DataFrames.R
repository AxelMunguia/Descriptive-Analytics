# Crear DataFrames
creado <- data.frame(Primer = c(1,2,3,4), Segundo = c(2,3,4,5))
creado
str(creado)


## Crear un DF

gender= c("H","M","M","H","H")
age =   c(23, 45, 21, 26,24)
family = c(2,3,5,6,1)
df1 = data.frame(gender,age,family,stringsAsFactors = T)
fix(df1) # Editar 
row = row.names(df1)
col = colnames(df1)
str(df1)
dimnames(df1)=list(row,col)
df1$ingresos = c(12000,12500,13000,14000,15000) # Anexar Columnas

# Cambiando tipo de datos
as.character(df1$age)
as.factor(df1$age)
as.numeric(df1$age)


df1[df1$gender=="M", ]-> dfmujer
str(dfmujer) # Se heredan todos los niveles del factor

# Eliminar levels
dfmujer=droplevels(dfmujer)
str(dfmujer)

# Select
library(tidyverse)
iris_petal = dplyr::select(iris,starts_with("petal")) # Te dará las columnas que empiezan con petal
iris_length = dplyr::select(iris,ends_with("Length"))

## SUbset

subset(iris,iris$Species=="versicolor")->versicolor
rownames(versicolor)=1:nrow(versicolor)








