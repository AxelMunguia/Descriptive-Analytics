data() # Datasets disponibles
data(package="ggplot2") # Los que tienes de esa librería
data(package=.packages(all.available = T))

## Comandos básicos 
iris_data<-data.frame(iris)
head(iris_data,4) # Primeras 4 filas
tail(iris_data) # Últimas 6 filas
str(iris_data) # Estructura del dataset
names(iris_data) # Nombres de las columnas 
names(iris_data) = c("Sepal.Length", "Sepal.Width", "Petal.Length", "Petal.Width",  "Species" )

# Obteniendo información del dames
rownames(iris_data) # Nombre de las filas
dimnames(iris_data) # Te devuelve nombre de las filas y columna
nrow(iris_data)
ncol(iris_data)
dim(iris_data)

# Subdataframes
iris_data$Sepal.Length # Para acceder a una sola columna
iris_data$Sepal.Length[1:10] # Hasta la n-esíma
iris_data[1:dim(iris_data)[1],1]
iris_data[iris_data$Species== 'setosa',]
iris_data[iris_data$Species== 'setosa'& iris_data$Sepal.Width>1,][c(1,3),c(1,3)]


