iris_data= iris
sapply(subset(iris_data,select = 1:4), FUN = mean)
sapply(subset(iris_data,select = 1:4), na.rm=TRUE,FUN = sum)
sapply(subset(iris_data,select = 1:4), FUN = function(x){sqrt(sum(x^2))})

# Aggregate

aggregate(Sepal.Length ~ Species, data=iris,FUN = mean,na.rm=T)

aggregate(cbind(Sepal.Length,Petal.Length)~Species, data=iris,FUN = mean,na.rm=T)

# Dataset de mtcars
head(mtcars)
str(mtcars)
mtcars$cyl= as.factor(mtcars$cyl)
mtcars$gear=as.factor(mtcars$gear)
mtcars$carb = as.factor(mtcars$carb)

aggregate(mpg~cyl+gear+carb,data=mtcars,FUN = mean,na.rm=T)
aggregate(cbind(mpg,carb,gear)~cyl,data=mtcars,FUN = mean,na.rm=T)

## Attach ( hacer las columnas variables globales)
attach(mtcars)
mpg
detach(mtcars)
mpg <- 5
attach(mtcars) # Como mpg es una variable global no te dejará sobreescribirla