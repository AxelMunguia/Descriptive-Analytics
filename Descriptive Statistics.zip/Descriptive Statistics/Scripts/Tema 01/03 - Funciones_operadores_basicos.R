# Ra�z
sqrt(2)
# exponencial
exp(2)
# logaritmo base e
log(100)
# logaritmo 10
log10(10)
# Cualquier base
log(10000,10)
# Valor absoluto
abs(-10)
# factorial
factorial(12)
# Combinaci�n binomial
choose(10,3) # Formas de acomodar m elementos # n!/(m!(n-m)!)
# Funciones trigonom�tricas (los argumentos R los interpreta como en radianes)
sin(pi/2); cos(pi); tan(0)
# Para utilizar grados tenemos que hacer una regla de 3 para pasar a grados
cos(60*pi/180)
sin(60*pi/180)
sinpi(.5*pi) #Es seno de pi/2
tan(pi)  # ~ 0
tan(pi/2) # ~ Inf
atan(pi)

# Plot de sin, cos, tan

x = seq(0,2*pi,0.1) # de 0 a 2*pi con paso 0.1
plot(x,sin(x),type = "l",col="blue",lwd = 3,xlab = expression(x), ylab = "")
lines(x, cos(x), col="green", lwd=3)
lines(x, tan(x), col="purple", lwd=3)
legend("bottomleft",col=c("blue","green","purple"),
       legend=c("Seno", "Coseno","Tangente"), lwd=3, bty = "l")

# N�meros en coma flotante
x = seq(0,1,0.02123)
print(x,3)# te redondea a n+1 
round(x,digits = 2)
floor(x)
ceiling(x)
trunc(sqrt(2)) # Similar a floor

# Crear funciones

miVar = 4
cuadrado = function(a){a^2}
cuadrado(4)

# Conocer las variables existentes
ls()

# remover variables
a = 2
rm(a)

# Eliminar todas las variables
a= 2; b=2;c =10
rm(list = ls())

# Operaciones b�sicas
# Paste concatena cualquier tipo de valores y los convierte en car.
Opbac= function(a,b){
  print("Suma")
  print(a+b)
  print("Resta")
  print(paste(sprintf(" %i - %i = ",b,a),b-a))
  print(paste(sprintf(" %i - %i = ",a,b),a-b))
  print("Producto")
  print(a*b)
  print("Cociente de Divisi�n Entero")
  print(paste(sprintf(" %i : %i = ",b,a),b%/%a))
  print(paste("Con resto  = ",b%%a))
  print(paste(sprintf(" %i : %i = ",a,b),a%/%b))
  print(paste("Con resto  = ",a%%b))
}


# N�meros complejos

a = 3+4i
sqrt(as.complex(a))
class(a)
complex(real = 4,imaginary = 4)
sqrt(as.complex(complex(real = 3,imaginary =4 )))
sqrt(as.complex(-5))
# Devuelve la parte real positiva
sqrt(3+2i)
cos(3+2i)

# Modulo -> z = sqrt(Re(valor)^2+Imaginario(valor)^2)
z= 3+2i
Mod(z)
# Argunmento -> arctan(Im(z)/Re(z)) = arcos(Re(z)/Mod(z)) = arcsin(Im(z)/Mod(z))
# Valor de (-pi,pi]
Arg(-1+0i)
# Conjugado
Conj(z)
# Parte Real e Imaginaria
Re(z)
Im(z)

### z = Mod(z) * (cos(Arg(z)) + sin(Arg(z))i)
complex(modulus =Mod(z), argument =Arg(z))

## Si hubi�ramos empezado a contar segundos a partir de las 12 campanadas 
## que marcan el inicio de 2018, �a qu� hora de qu� d�a de qu� a�o llegar�amos 
## a los 250 millones de segundos? �Cuidado con los a�os bisiestos!

diass = function(a,b,c){
  a = a
  a�o_indicado = b
  ult_a�o_biciesto = c
  segundos = 60 
  minutos = 60
  horas = 24
  dias = 365
  segundos_a�o = segundos*minutos*horas*dias
  a�os = a/ segundos_a�o #Te dar� los a�os
  decimales_a�o = a/ segundos_a�o - a%/% segundos_a�o
  parte_proporcional_a�o = decimales_a�o*dias # Te dar� los d�as del a�o
  decimales_dia = decimales_a�o*dias -trunc(decimales_a�o*dias)
  parte_proporcional_dia = decimales_dia*horas # Te dar� las horas del d�a
  decimales_hora= parte_proporcional_dia- trunc(parte_proporcional_dia)
  segundos_finales = decimales_hora*segundos # Te dar� los segundos
  DIFERENCIA = a�o_indicado - ult_a�o_biciesto
  total_a�os = a�o_indicado + trunc(a�os)
  diferencia_total = total_a�os-ult_a�o_biciesto
  dias_biciestos =diferencia_total/4
  
  print(sprintf("LLegaremos a los %i Segundos ",a))
  print(sprintf(" En : %f a�os",a�os)) 
  print(sprintf(" Con: %f d�as",parte_proporcional_a�o-dias_biciestos)) 
  print(sprintf(" Con: %i horas",parte_proporcional_dia)) 
  print(sprintf(" Con : %f segundos", segundos_finales))

  }
# M�s f�cil
dias = function(ult_a�o_biciesto,a�o_actual, tiempo=250000000){
  a�os = tiempo/(60*60*24*365)
  print(a�os)
  dias = (a�os - floor(a�os))*365
  horas = (dias - floor(dias))*24
  minutos = (horas - floor(horas))*60
  segundos = (minutos - floor(minutos))*60
  
  total_dias = ceiling((a�o_actual-ult_a�o_biciesto+a�os)/4)
  print(sprintf("LLegaremos a los %i Segundos ",tiempo))
  print(sprintf(" En : %f a�os",a�os)) 
  print(sprintf(" Con: %f d�as",dias-total_dias)) 
  print(sprintf(" Con: %f horas",horas))
  print(sprintf(" Con: %f minutos",minutos)) 
  print(sprintf(" Con : %f segundos", segundos))  
  
}
# Cread una funci�n que os resuelva una ecuaci�n de primer grado (de la forma Ax+B=0).
# Es decir, vosotros tendr�is que introducir como par�metros los coeficientes (en orden) 
# y la funci�n os tiene que devolver la soluci�n. Por ejemplo, si la ecuaci�n 
# es 2x+4=0, vuestra funci�n os tendr�a que devolver -2.
grado_poli = function(a,b,igualdad){
  igualdad = -1*b+c
  valor = igualdad/a
  sprintf("Tu ra�z es : %f",valor)
  }

