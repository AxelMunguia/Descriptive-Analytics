# Instalar tidyverse
install.packages("tidyverse",dependencies = TRUE)
library(tidyverse)

# Instalar magic para cuadrados m�gicos
install.packages("magic",dependencies = TRUE)
library(magic)
a= magic(5) #Suma lo mismo por filas y columnas
sum(a)
  
# Paquetes instalados
installed.packages()
