# Operaciones...

# Suma y Resta
3+4; 2-1

# Multiplicaci�n y Divsi�n
4*2; 3/5

# Potencia y Divisi�n entera
2^-8; 3%/%2

# Modulo (Resto-Residuo)
7%%3

# Car�cteres especiales
pi; Inf; NA; NaN; 1e06; c(1e06,2e05,1,2)

