# El bigote Inferior = max{m, Q_0.25 -1.5 (Q_0.75-Q_0.25)}
# El bigote Superior = max{m, Q_0.75 -1.5 (Q_0.75-Q_0.25)}
dados2= sample(1:50,15,T)
boxplot(dados2 )
dados3= sample(1:50,20,T)
boxplot(dados2,dados3, main="Diagrama de cajas")
boxplot(iris,names = names(iris),horizontal = T,notch =T,border = "red",varwidth = T,col = "blue")
names(iris)

# Más características
boxplot(circumference~Tree, data = Orange, ylab= "Crcunferencia del tronco (mm)", 
        main= "Boxplot de los naranjos en función del tipo de árbol")
boxplot(iris$Sepal.Length~iris$Species)
boxplot(Sepal.Length~Species, data=iris) # Lo mismo que arriba
# Interactivo
a = boxplot(Sepal.Width~Species, data=iris, col = c("green","cyan","gold"),notch = T)
medias = aggregate(Sepal.Width~Species, data=iris, FUN=mean)
points(medias,col="red", pch=15)
str(a)
a$stats
------------------------------
data =read.table("../r-basic-master/data/datacrab.txt",header = T)
boxplot(data)


# Dataframe de Insectos

a = InsectSprays
by(InsectSprays$count,InsectSprays$spray,FUN = mean)
head(a)
str(a)

# Análisis
by(InsectSprays$count,InsectSprays$spray,FUN = summary)
aggregate(count~spray,data=a,FUN=sd)
boxplot(count~spray,data=a,col="lightgreen")



