# Listas
x = c(10,-2,13,-4,35,26)
l = list(nombre="Temperatura",datos=x,media = mean(x),sumas=cumsum(x))
l[1];l[2];l[3];l[4] # Ingresa a los distintos niveles
l2[[2]][1]# Posición 1. Ingresamos a los datos y pedimos la primer posición
l2 =list(x)
l2[[1]][1]# Posición 1
l$nombre
l$datos
ll = list(1,2,3,4)
ll[1] # Ingresas directo a la posición porque no hay niveles
str(ll) # Structura Interna de la lista
str(l)
names(l)

# Modelo Linear (Lo regresa en modo lista)
lmodel = lm(c(1,2,3,4,5)~c(0,3,23,56,92))
lmodel$coefficients
summary(lmodel)