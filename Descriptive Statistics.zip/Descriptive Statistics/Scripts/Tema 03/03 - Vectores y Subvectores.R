# Vectores y Subvectores

a <- c(10,1,2,3,4,5,6,7,8)
a[length(a)]
b<-a[1:3]
d<-a[-1] # Elimina el número que se encuentre en ese índice
e<- a[-c(1,2,3)]
f<- a[a!=2 & a>3]

# wich
a= c(20:30,seq(0,by = 0.1, length.out = 41))
sum(a,na.rm = TRUE)
a[8:4] # Lo interpreta bien
a[seq(2,by = 2, length.out = length(a)/2)] # Los pares
a[seq(2,by=2,length(a))] # Los pares
a[-seq(2,by=2,length(a))] # Los impares
a[length(a):(length(a)-3)] # Los últimos 3
a[a%%2==0] # Los pares (modulo cero)
which(a!=3 & a!=1)
which.min(a) # Te da el índice. SI HAY MÁS DE UNO TE DARÁ TODOS.
min(a)
which(a==min(a)) # Te da el índice
which.max(a)
which(a==max(a))  # Te da el índice
which(is.na(a))
a[60]=43
a[which(is.na(a))]= mean(a,na.rm = TRUE)
a[!is.na(a)] # Cuales no son NA'S
cumsum(a[!is.na(a)])
na.omit(a)

# Limpiar atributos(Mensajes que te dicen que índices se eliminaron)
a= c(20:30,seq(0,by = 0.1, length.out = 41))
a[60]=43
a
x_clean= na.omit(a)
x_clean
attr(x_clean, "na_action")=NULL
attr(x_clean, "class")<-NULL

