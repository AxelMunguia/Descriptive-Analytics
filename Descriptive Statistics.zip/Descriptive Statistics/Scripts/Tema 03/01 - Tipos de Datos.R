# Funciones
x=seq(0,10)
max(x)
min(x)
length(x)
cumsum(x)
mean(x)
sort(x,decreasing = FALSE)
rev(x) # Invierte
prod(x)
rev(sort(x))

## Vectores
v1 = c(1,2,3,4,5) # Tienen que ser del mismo tipo

# Repeticiones
rep1 = rep("Axel",7)
rep2 = rep(2,20)

# Orden Jerárquico en los Vectores
# Logical: lógicos (TRUE o FALSE)
# Integer: números enteros, Z.
# numeric: números reales, R.
# Complex: números complejos, C.
#c Character: palabras

# scan nos deja ir ingresando los valores después de dar el enter

sc<- scan(dec = ".") # Se los asignas después de dar el enter
# Si le metes una url con formate txt. o csv. lo leerá.

# Modificar un vector
x<- c(1,2,3,4,5)
fix(x)
class(x)
nombres<- c("Axel", "Francisco","Munguia","Quintero")
fix(nombres)
class(nombres)

# Porgresiones y Secuencias

# Porgresión aritmética
seq1 = seq(0,10,by = 0.12345)

seq2 = seq(10,-10,by = -1)

seq3=seq(0,10,length.out = 100) # Número de divisiones

seq4= seq(0,by = 0.1, length.out = 101) # Con salto de hasta alcanzar n divisiones

seq5= seq(0:10) # No toma el primero y toma uno más del límite

# Concatenar

c(seq(0,10),0:10)
c(seq(0,10),rep('Axel',10))

# Aplicar funciones a cada uno de los elementos de un vector

x=1:10
x+pi
x*2*pi
2^x
 
# sapply
# lapply returns a list of the same length as X, each element of
# which is the result of applying FUN to the corresponding element of X.

a = c(1:10)
sapply(a, FUN = function(x){sqrt(x)})

cd = function(x){summary(lm((1:4)~c(1:3,x)))$r.squared}
sapply(a, FUN = cd)
lapply(a,FUN = cd)


