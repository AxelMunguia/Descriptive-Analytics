# Definir Matrices

mat = matrix(c(1,2,3,4,5,6),nrow =4,ncol = 2,byrow = T)
mat # Se repiten los números si no se los das completos

mat1 = matrix(1,nrow = 4, ncol = 3)
mat1

# Operaciones básicas
# %*% para multiplicar matrices (si quieres uno a uno es solo con *)
t(mat1)
mat1%*%t(mat1) # Tiene que venir transpuesta

a = cbind(c(1,2,3),c(4,5,6))
a
b = rbind(c(1,2,3),c(4,5,6))
b
d = a%*%b 
d
g = cbind(c(40,3,56,3),c(12,3,2,1),c(12,534,12,2),c(1,34,56,21))
g
det(g)
qr(g) #qr computes the QR decomposition of a matrix.
solve(g) # Sirve para calcular la inversa
round(solve(g)%*%g,2) # Te da la matriz identidad
library(Biodem)
mtx.exp(d,2)

# Resolver sistema de ecuaciones

solve(g,c(45,32,-12,45)) # Los valores del vector son a lo que está igualado

# Valores y Vectores propios
eigen(g) # Te da ambos 
eigen(g)$values
eigen(g)$vectors

# Ejercicio 
M = rbind(c(2,6,-8),c(0,6,-3),c(0,2,1))
P = eigen(M)$vectors
# M = P * D * P^-1
M_comprobación = round(P%*%diag(eigen(M)$values)%*%solve(eigen(M)$vectors),2)

# Construir matriz fila por fila o columna por columna

matrow = rbind(c(1,2,3,4),c(seq(10,40,by = 10)),c(1,2,3,4),c(seq(10,40,by = 10)))
matrow1 =cbind(c(seq(100,500,by = 100)),c(1,2,5,6,7))
matrow[1,2]
matrow[1,] # Toda la fila
matrow[,2]
matrow[1,c(1,2)]
matrow[c(1,2),3]
diag(c(1,2,3,4)) # Pone en diagonal el vector

# Más parámetros
diag(matrow)
nrow(matrow)
ncol(matrow)
dim(matrow)
sum(matrow)
prod(matrow)
colSums(matrow)
rowSums(matrow)
colMeans(matrow)
rowMeans(matrow)
# Matrices con valores imaginarios 

A = matrix(c(3-2i,5+3i,1+2i,2-1i),nrow = 2,byrow = T)
eigen(A)
mtx.exp(A,2)
solve(A , c(1-1i,4))
#det(A) # No está definido por complejos, pero es el producto de los valores propios
prod(eigen(A)$values)


# apply() a matrices

# Por filas

apply(matrow, MARGIN =1, FUN = function(x){sqrt(sum(x^2))}) # Filas
apply(matrow, MARGIN =2, FUN = function(x){sqrt(sum(x^2))}) # Columnas
apply(matrow, MARGIN =1, FUN = function(x){sqrt(x)}) # Toda la matriz
apply(matrow, MARGIN =c(1,2), FUN = function(x){(x^2)}) # ambas


# Dimension
(a= matrix(c(1,2,3,4),nrow = 2,ncol = 2))
dim(a)
a[-c(1),] # El negativo te da todas menos la indicada