# Factor: similar a un vector, pero con una restructura interna más amplia que permite ser usado
# para clasificar observaciones.

# Primero se define un vector y después se transforma un factor (factor() o as.factor())

nombres= c('Axel','Juan','Ana','Pedro','Rosa')
nombres.factor =factor(nombres) # Tiene niveles
nombres.as.factor = as.factor(nombres) 

# Parámetros
gender= c(rep("H",5),rep('M',5))
gender.factor = factor(gender)
gender.factor2 = as.factor(gender)
gender.factor3 = factor(gender, levels = c('M','H','B'))
gender.factor4 = factor(gender, levels = c('M','H','B'),labels = c('Mujer', 'Hombre',
                                                                   'Hermafrodita')) # Incorpora la etiqueta en los datos
levels(gender.factor4) # También cambia los niveles con las labels
# Asignando Niveles
levels(gender.factor4)= c('Femenino', ' Masculino','Híbrido')

# Enteros, Agrupando en menos clases

notas= c(1,3,4,5,7,8,9,2,10,9,9,9,8,7,6,4,5,6,7)
notas.factor=factor(notas)
levels(notas.factor)=c(rep("Reprobado",5),rep("Aprobado",length(levels(notas.factor))-5))


# Ordenar los factores

notas2= c(1,2,1,3,4,2,1,1,3,4,1,3)
notas2.factor=factor(notas2,levels = c(1,2,3,4), labels = c("Sus","Suf","Not","Exc"))
levels(notas2.factor)
facOrd = ordered(notas2,levels = c(1,2,3,4), labels = c("Sus","Suf","Not","Exc")) 
# Te los ordenas y cada uno es mayor que otro



