# Ejercicio

notas = sample(0:10,100,T)
L = c(0,5,6,7,9,10)
intervalos = cut(notas, breaks = L,right  = F,include.lowest = T)
niveles = levels(intervalos)
intervalos
M_Clase = (L[1:length(L)-1]+L[2:length(L)])/2
intervalos2 = cut(notas, breaks = L, labels = M_Clase, right = F, include.lowest = T)
intervalos3 = cut(notas, breaks = L, labels = F, right = F, include.lowest = T) # Si Labels False entonces toma el lugar de la posición
intervalos4 = cut(notas, breaks = L, labels = c("Reprobado","Baja Calificación","Regular","Bueno","Excelente"), 
                  right = F, include.lowest = T)
cut(notas, breaks = 2) 
table(intervalos4)
prop.table(table(intervalos4))
hist(notas)
c=seq(0,10,length.out = 6 )
hist(notas, breaks = c, right = F, include.lowest = T, plot = T) # Si le pones F te devuelve estadísticos






















